<?php include ('header.php'); ?>

    <div class="container-fluid">

      <!--Redireccion a index.php -->
      <ol class="breadcrumb">
        <li class="breadcrumb-item">
          <a href="index.php">Index</a>
        </li>
        <li class="breadcrumb-item active">Blank Page</li>
      </ol>

      <!-- Page Content -->
      <h1>Llamada</h1>
      <hr>
      <p>Contesto pero me cuelgas!!!</p>

    </div>


<?php include('footer.php'); ?>