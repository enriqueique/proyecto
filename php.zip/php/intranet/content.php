      <div id="content-wrapper">

        <div class="container-fluid">

          <!--Redireccion a index.php -->
          <ol class="breadcrumb">
            <li class="breadcrumb-item">
              <a href="index.php">Index</a>
            </li>
            <li class="breadcrumb-item active">Blank Page</li>
          </ol>

          <!-- Page Content -->
          <h1>Blank Page</h1>
          <hr>
          <p>Prueba de contenido</p>

        </div>