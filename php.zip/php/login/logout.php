<?php 

require "clases/login.php"; 
$logout = new Login();
$logout->endLogin();

?>