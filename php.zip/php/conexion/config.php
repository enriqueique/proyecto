<?php

    define('HOST', '198.91.81.7');
    define('USER', 'sanepita_user');
    define('PASS', '1234');
    define('NAME', 'sanepita_prueba');
    define('URL', 'http://sanepitafio.x10host.com/');

?>
